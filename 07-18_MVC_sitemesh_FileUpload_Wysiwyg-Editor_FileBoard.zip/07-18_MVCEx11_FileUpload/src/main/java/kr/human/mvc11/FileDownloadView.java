package kr.human.mvc11;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.AbstractView;

//다운로드를 책임질 객체
public class FileDownloadView extends AbstractView {

	@Override
	protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// 컨트롤러에서 전달해준 데이터를 받는다
		String oFileName = (String) model.get("oFileName"); // 원본 파일의 이름
		String sFileName = (String) model.get("sFileName"); // 저장 파일의 이름

		// 읽을 파일 객체를 지정
		@SuppressWarnings("deprecation")
		File file = new File(request.getRealPath("upload"), sFileName);

		// 다운로드 처리
		response.setContentType(getContentType());
		response.setContentLength((int) file.length());

		// 다운로드할 이름에 공백이나 한글 처리를 담당
		String filename = URLEncoder.encode(oFileName, "UTF-8").replace("\\+", "%20");// 파일을 다운로드 하면 공백을 +로 표시하는데, 그걸
																						// 공백으로 출력시킨다
		// "\\+"를 쓴 이유는 replace는 정규표현식만 사용되어야 하기 때문이다

		// 다운로드 할 이름과 타입을 지정한다
		response.setHeader("Content-Disposition", "attachment; filename=\"" + filename + "\";");// 다운 받을 파일이름 설정
		response.setHeader("Content-Transfer-Encoding", "binary");// binary해야 보여주지 않고 다운

		// 실제 다운로드를 실행한다
		OutputStream os = response.getOutputStream();
		FileInputStream fis = null;

		// 서버에서 읽어서 reponse를 쏴준다
		try {
			fis = new FileInputStream(file);
			FileCopyUtils.copy(fis, os);// 저장

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (fis != null)
				fis.close();
		}
		os.flush();
	}

}
